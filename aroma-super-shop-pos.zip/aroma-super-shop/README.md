# Aroma Super Shop POS

A production-oriented Laravel 13 POS + inventory starter for Aroma Super Shop.

## Included
- Role-based Admin / Salesman / Stock Worker access
- Barcode scanner and manual product search POS
- Stock-safe sales using database transactions and row locking
- Invoice printing
- Product catalogue with images, barcode, SKU, pricing and stock
- XLSX/XLS/CSV product import with duplicate protection by barcode/SKU
- Low-stock notifications for admins
- Dashboard, sales history and reports
- Profit calculation from purchase cost
- SQLite by default for easy setup; MySQL config is also included
- Feature test for the core sale flow

## Requirements
PHP 8.3+, Composer, and the PHP extensions required by Laravel/PhpSpreadsheet. Laravel 13 requires PHP 8.3 or newer.

## First setup
1. Install PHP 8.3+ and Composer.
2. Extract this folder.
3. In the project folder run:
   composer install
   copy .env.example .env  (Windows CMD)
   # or: cp .env.example .env (Git Bash/Linux/macOS)
   php artisan key:generate
   php artisan migrate --seed
   php artisan storage:link
   php artisan serve
4. Open http://127.0.0.1:8000

## Demo accounts
Admin: admin@aromasupershop.com / admin12345
Salesman: sales@aromasupershop.com / sales12345
Stock worker: stock@aromasupershop.com / stock12345

Change these passwords before real shop use.

## Excel import
The importer accepts XLSX, XLS and CSV. Recommended headers:
Product Name, Barcode, SKU, Purchase Price, Selling Price, Stock, Unit, Category, Min Stock

If a barcode already exists, that product is updated rather than duplicated. If only SKU exists, SKU is used for matching.

## Barcode scanning
A normal USB/Bluetooth barcode scanner that behaves like a keyboard works immediately: keep the POS search field focused and scan. Manual typing/search is also supported.

## Production notes
- Set APP_DEBUG=false in production.
- Use HTTPS.
- Use MySQL/PostgreSQL for a multi-terminal shop deployment.
- Configure regular database backups.
- Change demo credentials.
