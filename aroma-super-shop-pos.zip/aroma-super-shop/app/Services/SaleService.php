<?php
namespace App\Services;
use App\Models\{Product,Sale,StockMovement,User,ShopNotification};
use Illuminate\Support\Facades\DB; use Illuminate\Validation\ValidationException;
class SaleService {
 public function create(User $user,array $data):Sale {
  return DB::transaction(function()use($user,$data){
   $items=$data['items']??[]; if(!$items) throw ValidationException::withMessages(['items'=>'Cart is empty.']);
   $subtotal=0; $prepared=[];
   foreach($items as $item){
    $product=Product::lockForUpdate()->find((int)$item['product_id']);
    if(!$product||!$product->active) throw ValidationException::withMessages(['items'=>'One product is unavailable.']);
    $qty=(float)$item['quantity']; if($qty<=0) throw ValidationException::withMessages(['items'=>'Invalid quantity.']);
    if((float)$product->stock < $qty) throw ValidationException::withMessages(['items'=>"Insufficient stock: {$product->name} ({$product->stock} available)."]);
    $price=(float)$product->selling_price; $discount=(float)($item['discount']??0); $line=max(0,($price*$qty)-$discount); $subtotal+=$line;
    $prepared[]=['product'=>$product,'quantity'=>$qty,'price'=>$price,'discount'=>$discount,'line'=>$line];
   }
   $discount=(float)($data['discount']??0); $tax=(float)($data['tax']??0); $total=max(0,$subtotal-$discount+$tax); $paid=(float)($data['paid']??0);
   if($paid<$total) throw ValidationException::withMessages(['paid'=>'Paid amount is less than total.']);
   $sale=Sale::create(['invoice_no'=>$this->invoiceNo(),'user_id'=>$user->id,'subtotal'=>$subtotal,'discount'=>$discount,'tax'=>$tax,'total'=>$total,'paid'=>$paid,'change'=>$paid-$total,'payment_method'=>$data['payment_method']??'cash','status'=>'completed','notes'=>$data['notes']??null]);
   foreach($prepared as $p){$product=$p['product'];$product->stock=(float)$product->stock-$p['quantity'];$product->save();$sale->items()->create(['product_id'=>$product->id,'product_name'=>$product->name,'barcode'=>$product->barcode,'price'=>$p['price'],'quantity'=>$p['quantity'],'discount'=>$p['discount'],'line_total'=>$p['line']]);StockMovement::create(['product_id'=>$product->id,'user_id'=>$user->id,'type'=>'sale','quantity'=>-$p['quantity'],'balance_after'=>$product->stock,'reference'=>$sale->invoice_no,'note'=>'POS sale']); if($product->stock <= $product->min_stock){foreach(User::where('role','admin')->where('active',true)->get() as $admin) ShopNotification::firstOrCreate(['user_id'=>$admin->id,'title'=>'Low stock alert','message'=>"{$product->name} has only {$product->stock} {$product->unit} left.",'type'=>'warning','read'=>false]);}}
   return $sale->load('items','user');
  });
 }
 private function invoiceNo():string{return 'ARS-'.now()->format('Ymd-His').'-'.str()->upper(str()->random(4));}
}
