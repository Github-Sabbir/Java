<?php
namespace App\Http\Controllers;
use App\Models\ShopNotification;
class NotificationController extends Controller {public function index(){return view('notifications.index',['notifications'=>ShopNotification::where('user_id',auth()->id())->latest()->paginate(30)]);}public function read(ShopNotification $notification){abort_unless($notification->user_id===auth()->id(),403);$notification->update(['read'=>true]);return back();}public function readAll(){ShopNotification::where('user_id',auth()->id())->where('read',false)->update(['read'=>true]);return back();}}
