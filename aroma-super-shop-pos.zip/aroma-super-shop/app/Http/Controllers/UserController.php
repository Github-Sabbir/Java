<?php
namespace App\Http\Controllers;
use App\Models\User; use Illuminate\Http\Request;
class UserController extends Controller {public function index(){return view('users.index',['users'=>User::latest()->paginate(20)]);}public function store(Request $r){$d=$r->validate(['name'=>'required|string|max:255','email'=>'required|email|unique:users,email','password'=>'required|string|min:8','role'=>'required|in:admin,salesman,stock_worker']);User::create($d+['active'=>true]);return back()->with('success','User created.');}public function toggle(User $user){if($user->id===auth()->id())return back()->withErrors(['user'=>'You cannot disable your own account.']);$user->update(['active'=>!$user->active]);return back()->with('success','User status updated.');}}
