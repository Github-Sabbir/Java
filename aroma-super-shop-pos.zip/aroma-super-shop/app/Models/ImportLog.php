<?php
namespace App\Models; use Illuminate\Database\Eloquent\Model;
class ImportLog extends Model{protected $fillable=['user_id','filename','rows_total','created','updated','skipped','errors'];}
