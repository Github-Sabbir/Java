<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable; use Illuminate\Notifications\Notifiable; use Illuminate\Database\Eloquent\Relations\HasMany;
class User extends Authenticatable {use Notifiable; protected $fillable=['name','email','password','role','active']; protected $hidden=['password','remember_token']; protected function casts():array{return ['password'=>'hashed','active'=>'boolean'];} public function sales():HasMany{return $this->hasMany(Sale::class);} public function isAdmin():bool{return $this->role==='admin';} public function isSalesman():bool{return $this->role==='salesman';} public function isStockWorker():bool{return $this->role==='stock_worker';}}
