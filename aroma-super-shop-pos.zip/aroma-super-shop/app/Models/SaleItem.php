<?php
namespace App\Models; use Illuminate\Database\Eloquent\Model; use Illuminate\Database\Eloquent\Relations\BelongsTo;
class SaleItem extends Model{protected $fillable=['sale_id','product_id','product_name','barcode','price','quantity','discount','line_total'];protected $casts=['price'=>'decimal:2','quantity'=>'decimal:3','discount'=>'decimal:2','line_total'=>'decimal:2'];public function sale():BelongsTo{return $this->belongsTo(Sale::class);}public function product():BelongsTo{return $this->belongsTo(Product::class);}}
