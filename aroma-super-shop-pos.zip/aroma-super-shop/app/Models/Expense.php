<?php
namespace App\Models; use Illuminate\Database\Eloquent\Model; use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Expense extends Model{protected $fillable=['user_id','title','amount','note','expense_date'];protected $casts=['amount'=>'decimal:2','expense_date'=>'date'];public function user():BelongsTo{return $this->belongsTo(User::class);}}
