<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder; use App\Models\{User,Category,Supplier,Product};
class DatabaseSeeder extends Seeder {public function run():void{
 User::firstOrCreate(['email'=>'admin@aromasupershop.com'],['name'=>'Aroma Admin','password'=>'admin12345','role'=>'admin','active'=>true]);
 User::firstOrCreate(['email'=>'sales@aromasupershop.com'],['name'=>'Salesman','password'=>'sales12345','role'=>'salesman','active'=>true]);
 User::firstOrCreate(['email'=>'stock@aromasupershop.com'],['name'=>'Stock Worker','password'=>'stock12345','role'=>'stock_worker','active'=>true]);
 foreach(['Grocery','Beverages','Snacks','Personal Care','Household','Other'] as $name) Category::firstOrCreate(['slug'=>str($name)->slug()],['name'=>$name,'active'=>true]);
 Supplier::firstOrCreate(['name'=>'Default Supplier']);
}}
