<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration {public function up():void{Schema::create('expenses',function(Blueprint $t){$t->id();$t->foreignId('user_id')->constrained();$t->string('title');$t->decimal('amount',12,2);$t->text('note')->nullable();$t->date('expense_date');$t->timestamps();});}public function down():void{Schema::dropIfExists('expenses');}};
