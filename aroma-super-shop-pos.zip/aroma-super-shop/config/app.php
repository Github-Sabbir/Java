<?php
return [
 'name' => env('APP_NAME','Aroma Super Shop'),
 'env' => env('APP_ENV','production'),
 'debug' => (bool) env('APP_DEBUG',false),
 'url' => env('APP_URL','http://localhost'),
 'timezone' => 'Asia/Dhaka',
 'locale' => env('APP_LOCALE','en'),
 'fallback_locale' => env('APP_FALLBACK_LOCALE','en'),
 'key' => env('APP_KEY'), 'cipher' => 'AES-256-CBC',
 'maintenance' => ['driver'=>'file'],
];
